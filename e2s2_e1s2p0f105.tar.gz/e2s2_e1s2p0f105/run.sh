#!/bin/bash

if [ -e ./input.pdb ]
then
    gmx grompp -f md.mdp -p /home/rakesh/adaptive/closedtop/protein.top -c input.pdb -o md.tpr 
fi

nohup gmx mdrun -v -stepout 10 -s md.tpr -deffnm md -c md.pdb
