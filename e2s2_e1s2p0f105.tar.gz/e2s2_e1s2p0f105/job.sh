#!/bin/bash

cd /home/rakesh/adaptive/input/e1s2_closed1
/home/rakesh/adaptive/input/e1s2_closed1/run.sh
mv *.xtc /home/rakesh/adaptive/data/e1s2_closed1